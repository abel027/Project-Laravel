<?php

use App\Models\Post;
use App\Models\User;
use App\Models\Jurusan;
use App\Models\Student;
use App\Models\Category;
use GuzzleHttp\Middleware;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\PendudukController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AdminCategoryController;
use App\Http\Controllers\DashboardAdministrasiController;
use App\Http\Controllers\DashboardPostController;
use App\Http\Controllers\DashboardPendudukController;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home', ['title' => 'Home Page', 'active' => 'home']);
});

Route::get('/about-me', function () {
    return view('about-me', [
        'nama' => 'Muhammad Abbel Prasetya', 'no_bp' => '2101092055', 'email' => 'm.abelprasetya@gmail.com',
        'gambar' => 'pic-abel.jpg', 'title' => 'Tentang Saya', 'active' => 'about-me'
    ]);
});

Route::get('/post', [PostController::class, 'index']);
Route::get('/post/{post:slug}', [PostController::class, 'single']);
Route::get('/post/categories/{category:slug}', function (Category $category) {
    return view('post.index', [
        'title' => 'Category' . $category->name, 'active' => 'post',
        'category' => $category->name,
        'data_posts' => $category->posts->load(['author', 'category'])
    ]);
});

Route::get('/post/users/{user:username}', function (User $user) {
    return view('post.index', [
        'title' => 'Author' . $user->name, 'active' => 'post',
        'author' => $user->name,
        'data_posts' => $user->posts->load(['author', 'category'])
    ]);
});

Route::get('/student', [StudentController::class, 'index']);
Route::get('/student/{student:nim}', [StudentController::class, 'single']);

Route::get('/student/jurusan/{jurusan:slug}', function (Jurusan $jurusan) {
    return view('student.jurusan', [
        'title' => 'Jurusan' . $jurusan->name_jurusan,
        'active' => 'student',
        'mhs' => $jurusan->students
    ]);
});

Route::get('/login', [LoginController::class, 'index'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout'])->middleware('auth');

Route::get('/register', [RegisterController::class, 'index']);
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/dashboard', function () {
    return view('dashboard.index', ['title' => 'Home']);
})->middleware('auth');


Route::get('/dashboard/post/checkSlug', [DashboardPostController::class, 'checkSlug'])->middleware('auth');
Route::resource('/dashboard/post', DashboardPostController::class)->middleware('auth');


Route::resource('/dashboard/barang2055', BarangController::class)->except('show');

Route::get('/barang2055', [BarangController::class, 'index']);

Route::resource('/dashboard/penduduk2055', DashboardPendudukController::class)->middleware('auth')->except('show');
Route::get('/dashboard/penduduk2055/checkKode', [DashboardPendudukController::class, 'checkode'])->middleware('auth');


Route::resource('/dashboard/administrasi2055', DashboardAdministrasiController::class)->middleware('auth')->except('show');
Route::get('/dashboard/administrasi2055/checkKode', [DashboardAdministrasiController::class, 'checkode'])->middleware('auth');