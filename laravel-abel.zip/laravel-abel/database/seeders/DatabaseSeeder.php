<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Jurusan;
use App\Models\Mahasiswa;
use App\Models\Post;
use App\Models\Student;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::factory(10)->create();


        
        Category::create([
            'name' => 'Mobile Programming',
            'slug' => 'mobile-programming'
        ]);

        Category::create([
            'name' => 'Web Programming',
            'slug' => 'web-programming'
        ]);
        

        /** *
        Jurusan::create([
            'name_jurusan' => 'Teknologi Informasi',
            'slug' => 'teknologi-informasi'
        ]);

        Jurusan::create([
            'name_jurusan' => 'Teknik Sipil',
            'slug' => 'teknik-sipil'
        ]);
        */
        
    

        /** 
        User::create([
            'name' => 'Muhammad Abbel',
            'email' => 'm.abelprasetya05@gmail.com',
            'password' => bcrypt('123456')
        ]);

        User::create([
            'name' => 'Nauval',
            'email' => 'nopal05@gmail.com',
            'password' => bcrypt('123456')
        ]);

        */
        
        
 
         // isi data user sebanyak 10 record //
        
        
        /** 
        Category::create([
            'name' => 'Personal',
            'slug' => 'personal'
        ]);

        Category::create([
            'name' => 'Web Programming',
            'slug' => 'web-programming'
        ]);
         
        */

        // Isi data post sebanyak 10 record
        
        

    
        /** 
        Mahasiswa::factory(10)->create();
        */
        

        Post::factory(20)->create();

        //Student::factory(10)->create();

        /** 
        Post::create([
            'title' => 'Judul Pertama',
            'slug' => 'judul-pertama',
            'category_id' => 1,
            'user_id' => 1,
            'excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores.',
            'body' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores, repellat enim laboriosam autem quidem inventore eligendi molestias placeat alias, earum atque odit recusandae? Debitis aut praesentium voluptatem atque, consequatur aperiam error ex repudiandae? Adipisci deserunt sit, esse in consectetur excepturi explicabo, ipsum maiores unde cupiditate fuga doloribus? Unde, accusamus impedit exercitationem a assumenda perferendis deleniti saepe, rerum fuga quisquam quod velit voluptate architecto possimus quas. Nostrum, praesentium cumque. Ratione dignissimos doloremque dolore nisi commodi expedita quam exercitationem repudiandae minima nostrum odio, dolorum facere consequatur, nihil qui illum. Suscipit unde reiciendis omnis incidunt corporis adipisci expedita ullam exercitationem nostrum, fuga sed alias repellendus eius aliquid quos iure officia praesentium iste? Qui officiis laborum iusto.'
        ]);

        Post::create([
            'title' => 'Judul Kedua',
            'slug' => 'judul-kedua',
            'category_id' => 1,
            'user_id' => 1,
            'excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores.',
            'body' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores, repellat enim laboriosam autem quidem inventore eligendi molestias placeat alias, earum atque odit recusandae? Debitis aut praesentium voluptatem atque, consequatur aperiam error ex repudiandae? Adipisci deserunt sit, esse in consectetur excepturi explicabo, ipsum maiores unde cupiditate fuga doloribus? Unde, accusamus impedit exercitationem a assumenda perferendis deleniti saepe, rerum fuga quisquam quod velit voluptate architecto possimus quas. Nostrum, praesentium cumque. Ratione dignissimos doloremque dolore nisi commodi expedita quam exercitationem repudiandae minima nostrum odio, dolorum facere consequatur, nihil qui illum. Suscipit unde reiciendis omnis incidunt corporis adipisci expedita ullam exercitationem nostrum, fuga sed alias repellendus eius aliquid quos iure officia praesentium iste? Qui officiis laborum iusto.'
        ]);

        Post::create([
            'title' => 'Judul Ketiga',
            'slug' => 'judul-ketiga',
            'user_id' => 2,
            'category_id' => 2,
            'excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores.',
            'body' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores, repellat enim laboriosam autem quidem inventore eligendi molestias placeat alias, earum atque odit recusandae? Debitis aut praesentium voluptatem atque, consequatur aperiam error ex repudiandae? Adipisci deserunt sit, esse in consectetur excepturi explicabo, ipsum maiores unde cupiditate fuga doloribus? Unde, accusamus impedit exercitationem a assumenda perferendis deleniti saepe, rerum fuga quisquam quod velit voluptate architecto possimus quas. Nostrum, praesentium cumque. Ratione dignissimos doloremque dolore nisi commodi expedita quam exercitationem repudiandae minima nostrum odio, dolorum facere consequatur, nihil qui illum. Suscipit unde reiciendis omnis incidunt corporis adipisci expedita ullam exercitationem nostrum, fuga sed alias repellendus eius aliquid quos iure officia praesentium iste? Qui officiis laborum iusto.'
        ]);

        Post::create([
            'title' => 'Judul Keempat',
            'slug' => 'judul-keempat',
            'user_id' => 2,
            'category_id' => 2,
            'excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores.',
            'body' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores, repellat enim laboriosam autem quidem inventore eligendi molestias placeat alias, earum atque odit recusandae? Debitis aut praesentium voluptatem atque, consequatur aperiam error ex repudiandae? Adipisci deserunt sit, esse in consectetur excepturi explicabo, ipsum maiores unde cupiditate fuga doloribus? Unde, accusamus impedit exercitationem a assumenda perferendis deleniti saepe, rerum fuga quisquam quod velit voluptate architecto possimus quas. Nostrum, praesentium cumque. Ratione dignissimos doloremque dolore nisi commodi expedita quam exercitationem repudiandae minima nostrum odio, dolorum facere consequatur, nihil qui illum. Suscipit unde reiciendis omnis incidunt corporis adipisci expedita ullam exercitationem nostrum, fuga sed alias repellendus eius aliquid quos iure officia praesentium iste? Qui officiis laborum iusto.'
        ]);

        Post::create([
            'title' => 'Judul Kelima',
            'slug' => 'judul-kelima',
            'user_id' => 2,
            'category_id' => 2,
            'excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores.',
            'body' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem ad tempora aut ipsam est totam maiores, repellat enim laboriosam autem quidem inventore eligendi molestias placeat alias, earum atque odit recusandae? Debitis aut praesentium voluptatem atque, consequatur aperiam error ex repudiandae? Adipisci deserunt sit, esse in consectetur excepturi explicabo, ipsum maiores unde cupiditate fuga doloribus? Unde, accusamus impedit exercitationem a assumenda perferendis deleniti saepe, rerum fuga quisquam quod velit voluptate architecto possimus quas. Nostrum, praesentium cumque. Ratione dignissimos doloremque dolore nisi commodi expedita quam exercitationem repudiandae minima nostrum odio, dolorum facere consequatur, nihil qui illum. Suscipit unde reiciendis omnis incidunt corporis adipisci expedita ullam exercitationem nostrum, fuga sed alias repellendus eius aliquid quos iure officia praesentium iste? Qui officiis laborum iusto.'
        ]);

      */
    }
}