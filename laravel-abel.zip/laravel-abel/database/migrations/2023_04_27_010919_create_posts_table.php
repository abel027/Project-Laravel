<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            //category_id adalah foreign key ke table categories (relasi)
            $table->foreignId('category_id');
            //user_id adalah foreign key ke table users
            $table->foreignId('user_id');
            $table->string('title');
            //unique artinya tidak boleh lebih dari satu\\
            $table->string('slug')->unique();
            $table->string('excerpt');
            $table->text('body');
            $table->string('gambar')->nullable();
            $table->timestamp('publish_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
};
