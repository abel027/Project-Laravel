<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('Penduduk2055s', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('noktp')->unique();
            $table->string('jenkel');
            $table->string('tempat_lhr');
            $table->date('tgl_lhr');
            $table->string('agama');
            $table->string('gambar');
            $table->foreignId('status2055_id');
            $table->foreignId('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Penduduk2055');
    }
};
