<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Student>
 */
class StudentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            //
            'nim' => "2122".$this->faker->unique()->randomNumber(2),   
            'nama' => $this->faker->name(mt_rand(2,8)),
            'alamat' => $this->faker->streetAddress(),
            'gambar' => 'no-image.jpg',
            'jurusan_id' => mt_rand(1,2)
        ];
    }
}
