
<?php $__env->startSection('nauval-maulana'); ?>
    <h2><?php echo e($post['title']); ?></h2>
    <h5>Penulis : <?php echo e($post['penulis']); ?></h5>
    <p>
        <?php echo e($post['body']); ?>

    </p>
    <a href="/posts">Kembali ke Posts</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/post.blade.php ENDPATH**/ ?>