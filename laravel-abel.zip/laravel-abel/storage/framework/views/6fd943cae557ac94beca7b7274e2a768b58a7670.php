
<?php $__env->startSection('admin-abel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <strong>Info</strong> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-8">
            <a href="/dashboard/penduduk2055/create" class="btn btn-success"><span data-feather='plus-circle'></span>
                Tambah</i></a>
        </div>
        <div class="col-lg-4">
            <form action="/dashboard/penduduk2055" method="get">
                <div class="input-group flex-nowrap">
                    <input type="text" class="form-control" placeholder="Cari" name="search"
                        value="<?php echo e(request('search')); ?>" aria-label="Username" aria-describedby="addon-wrapping">
                    <button type="submit" class="input-group-text btn btn-outline-success"><span
                            data-feather="search"></span></button>
                </div>
            </form>
        </div>
    </div>

    <!-- jika data ditemukan  atau data tersedia -->

    <div class="table-responsive-lg">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama</th>
                    <th scope="col">KTP</th>
                    <th scope="col">Status</th>
                    <th scope="col">Foto KTP</th>
                    <th scope="col">Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        <td scope="row"><?php echo e($penduduks->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->noktp); ?></td>
                        <td><?php echo e($item->status2055->status); ?></td>
                        <td>
                            <?php if($item->gambar): ?>
                                <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>" class="img-fluid mt-2 d-block"
                                    width="150" alt="<?php echo e($item->gambar); ?>">
                            <?php else: ?>
                                <img src="https://source.unsplash.com/1200x100?<?php echo e($item->status2055->status); ?>"
                                    class="img-fluid mt-2" alt="<?php echo e($item->status2055->status); ?>">
                            <?php endif; ?>
                        </td>

                        <td>
                            <a href="/dashboard/penduduk2055/<?php echo e($item->noktp); ?>/edit" class="badge bg-primary"><span
                                    data-feather="edit"></span></a>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                <form action="/dashboard/penduduk2055/<?php echo e($item->noktp); ?>" method="post" class="d-inline  ">
                                    <!-- Timpa method Post menjadi delete -->
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        onclick="return confirm('Apakah anda yakin Ingin hapus ? <?php echo e($item->name); ?>')"
                                        class="badge bg-danger border-0">
                                        <span data-feather="x-circle"></span>
                                    </button>
                                </form>
                            <?php endif; ?>

                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end">
        <!--Menampilkan page/halaman-->
        <?php echo e($penduduks->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/penduduk2055/index.blade.php ENDPATH**/ ?>