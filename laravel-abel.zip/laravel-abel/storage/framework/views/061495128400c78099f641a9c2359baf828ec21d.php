
<?php $__env->startSection('nauval-maulana'); ?>

    <?php $__currentLoopData = $data_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="mb-3">
            <h1><?php echo e($item['title']); ?></h2>
            <h3>Penulis : <?php echo e($item['penulis']); ?></h3>
            <p>
                <?php echo e($item['excerpt']); ?>

            </p>
            <a href="/post/<?php echo e($item['slug']); ?>">Read more..</a>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/posts.blade.php ENDPATH**/ ?>