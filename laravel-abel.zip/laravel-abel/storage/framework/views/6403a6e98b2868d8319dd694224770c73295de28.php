
<?php $__env->startSection('admin-nauval'); ?>
    Halaman Dashboard
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/dashboard/index.blade.php ENDPATH**/ ?>