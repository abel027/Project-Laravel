<!--agar terhubung ke folder layouts-->

<?php $__env->startSection('Muhammad-Abbel'); ?>
<h3 class="text-center"><?php echo e($title); ?></h3>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="/student" method="get">

                <div class="input-group mb-3">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Search">
                    <button class="btn btn-success" type="submit">Seacrh</button>
                </div>
            </form>
        </div>
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Jurusan</th>
                <th scope="col">Gambar</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mhs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                    <td scope="row"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->nim); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td>
                        <a href="/student?jurusan=<?php echo e($item->jurusan->slug); ?>"> <?php echo e($item->jurusan->name_jurusan); ?></td>
                    <td>
                        <img src="/images/mhs/<?php echo e($item->gambar); ?>" alt="<?php echo e($item['nim']); ?>" class="img-thumbnail rounded-circle" width="90">
                    </td>
                    <td>
                        <a href="/student/<?php echo e($item->nim); ?>" class="btn btn-warning"> Detail </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/student/index.blade.php ENDPATH**/ ?>