<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3 sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" aria-current="page" href="/dashboard">
                    <span data-feather="home" class="align-text-bottom"></span>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard/post*') ? 'active' : ''); ?>" href="/dashboard/post">
                    <span data-feather="file-text" class="align-text-bottom"></span>
                    My Posts
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard/barang2055*') ? 'active' : ''); ?>"
                    href="/dashboard/barang2055">
                    <span data-feather="box" class="align-text-bottom"></span>
                    Barang
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard/penduduk2055*') ? 'active' : ''); ?>"
                    href="/dashboard/penduduk2055">
                    <span data-feather="box" class="align-text-bottom"></span>
                    Penduduk
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard/administrasi2055*') ? 'active' : ''); ?>"
                    href="/dashboard/administrasi2055">
                    <span data-feather="box" class="align-text-bottom"></span>
                    Administrasi
                </a>
            </li>

        </ul>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1">
                <span>Administrator</span>
            </h6>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('dashboard/category*') ? 'active' : ''); ?>" aria-current="page"
                        href="/dashboard/category">
                        <span data-feather="file" class="align-text-bottom"></span>
                        Category
                    </a>
                </li>
            </ul>
        <?php endif; ?>
    </div>
</nav>
<?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/layouts/nav.blade.php ENDPATH**/ ?>