
<?php $__env->startSection('admin-nauval'); ?>
    <div class="row">

        <div class="col-lg-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  <strong>Info!</strong> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-8">
            <a href="/dashboard/categories/create" class="btn btn-success"><span data-feather='plus-circle'></span> Tambah</a>
        </div>
        <div class="col-lg-4">
            <form action="/dashboard/categories" method="get">
                <div class="input-group flex-nowrap">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" 
                    placeholder="Cari" aria-label="Username">
                    <button type="submit" class="input-group-text btn btn-outline-success"><span
                             data-feather="search"></span></button>
                </div>
            </form>
        </div>
    </div>

    <div class="table-responsive-lg">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        <td scope="row"><?php echo e($categories->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($item->category->name); ?></td>
                        <td>
                            <a href="/dashboard/categories/<?php echo e($item->slug); ?>" class="badge bg-warning"><span data-feather="eye"></span></a>
                            <a href="/dashboard/categories/<?php echo e($item->slug); ?>/edit" class="badge bg-primary"><span data-feather="edit"></span></a>
                            <form action="/dashboard/categories/<?php echo e($item->slug); ?>" class="d-inline" method="post">
                                <!-- Timpa method post menjadi delete -->
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" onclick="return confirm('Apakah anda yakin ingin menghapus post <?php echo e($item->title); ?>?')" class="badge bg-danger border-0">
                                    <span data-feather="trash-2"></span>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end">
        <!-- Menampilkan page/halaman -->
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/dashboard/categories/index.blade.php ENDPATH**/ ?>