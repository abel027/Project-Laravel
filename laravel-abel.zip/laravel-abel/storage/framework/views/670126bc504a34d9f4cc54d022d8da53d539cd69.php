

<?php $__env->startSection('Nauval-Maulana'); ?>
    <article>
        <p>NIM : <?php echo e($student->nim); ?></p>
        <p>Nama : <?php echo e($student->nama); ?></p>
        <p>No. Telpon : <?php echo e($student->no_telpn); ?></p>
        <p>Alamat : <?php echo e($student->alamat); ?></p>
        <P>Jurusan : <a href="/student/jurusans/<?php echo e($student->jurusan->slug); ?>"> <?php echo e($student->jurusan->name_jurusan); ?></a></P>
        <p>Gambar : </p>
        <p>
            <img src="/images/mhs/<?php echo e($student->gambar); ?>" alt="<?php echo e($student['nim']); ?>" class="img-thumbnail rounded-circle" width="90">
        </p>

        <a href="/student">Kembali Ke Halaman Utama</a>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/student/single.blade.php ENDPATH**/ ?>