<!--agar terhubung ke folder layouts-->


<?php $__env->startSection('Muhammad-Abbel'); ?>
    <h3>Nama Lengkap : <?php echo e($nama); ?></h3> 
    <h3>No.Bp : <?php echo e($no_bp); ?></h3> 
    <h3>Email : <?php echo e($email); ?></h3> 
    <p>
        <img src="/images/<?php echo e($gambar); ?>" alt="<?php echo e($nama); ?>" class="rounded-circle" width="80">
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/about-me.blade.php ENDPATH**/ ?>