
<?php $__env->startSection('nauval-maulana'); ?>

    
        <div class="table-responsive-lg">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">Nim</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Gambar</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data_mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        <td><?php echo e($item['nim']); ?></td>
                        <td><?php echo e($item['nama']); ?></td>
                        <td><img src="/images/<?php echo e($item['gambar']); ?>" alt="<?php echo e($item['nama']); ?>" class="rounded-circle" width="100"></td>
                        <td><a name="" id="" class="btn btn-danger" href="/detail_mhs/<?php echo e($item['nim']); ?>" role="button">Detail</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
<?php $__env->stopSection(); ?>
        

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/mahasiswa.blade.php ENDPATH**/ ?>