
<?php $__env->startSection('admin-abel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h2><?php echo e($post->title); ?></h2>
            <a href="/dashboard/post" class="btn btn-success 
        text-decoration-none"><span data-feather="arrow-left"
                    class="align-text-bottom"></span> Kembali</a>
            <a href="/dashboard/post/<?php echo e($post->slug); ?> /edit " class="btn btn-primary"><span data-feather="edit"></span>
                Edit</a>
            <form action="" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($post->id); ?>">
                <button type="submit" onclick="confirm('Apakah anda yakin ingin menghapus? <?php echo e($post->title); ?>')"
                    class="btn btn-danger"><span data-feather="trash-2">
                    </span>Hapus</button>
            </form>

            <?php if($post->gambar): ?>
                <img src="<?php echo e(asset('storage/' . $post->gambar)); ?>" class="img-fluid mt-2 d-block " alt="<?php echo e($post->category->name); ?>">
            <?php else: ?>
                <img src="https://source.unsplash.com/1200x400? <?php echo e($post->category->name); ?>" class="img-fluid mt-2 d-block"
                    alt="<?php echo e($post->category->name); ?>">
            <?php endif; ?>

            <article class="fs-5">
                <?php echo $post->body; ?>

            </article>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/post/view.blade.php ENDPATH**/ ?>