
<?php $__env->startSection('nauval-maulana'); ?>

        <h5>Nim : <?php echo e($mahasiswa['nim']); ?></h5>
        <h5>Nama : <?php echo e($mahasiswa['nama']); ?></h5>
        <h5>No.Telp : <?php echo e($mahasiswa['no_telp']); ?></h5>
        <h5>Alamat : <?php echo e($mahasiswa['alamat']); ?></h5>
        <p>
            <img src="/images/<?php echo e($mahasiswa['gambar']); ?>" alt="<?php echo e($mahasiswa['nim']); ?>" class="rounded-circle" width="100">
        </p>
        <a href="/mahasiswa">Kembali</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/detail_mhs.blade.php ENDPATH**/ ?>