
<?php $__env->startSection('Nauval-Maulana'); ?>

<h2 class="text-center mb-3">Category : <?php echo e($category); ?></h2>
    <?php $__currentLoopData = $data_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="mb-3">
            <h2><?php echo e($item->title); ?></h2>
            <h5>By : <a href="/post/users/<?php echo e($item->author->username); ?>"><?php echo e($item->author->name); ?></a> 
                In <a href="/post/categories/<?php echo e($item->category->slug); ?>"> <?php echo e($item->category->name); ?></a>
            </h5>
            <p> 
                <?php echo e($item->excerpt); ?>

            </p>
            <a href="/post/<?php echo e($item->slug); ?>">Read More...</a>

        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/post/categories.blade.php ENDPATH**/ ?>