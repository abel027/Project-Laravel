
<?php $__env->startSection('admin-abel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <a href="/dashboard/penduduk2055" class="btn btn-success 
        text-decoration-none"><span data-feather="arrow-left"
                    class="align-text-bottom"></span> Kembali</a>
            <a href="/dashboard/penduduk2055/<?php echo e($penduduks->slug); ?> /edit " class="btn btn-primary"><span data-feather="edit"></span>
                Edit</a>
            <form action="" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($penduduks->id); ?>">
                <button type="submit" onclick="confirm('Apakah anda yakin ingin menghapus? <?php echo e($penduduks->title); ?>')"
                    class="btn btn-danger"><span data-feather="trash-2">
                    </span>Hapus</button>
            </form>

            <?php if($penduduks->gambar): ?>
                <img src="<?php echo e(asset('storage/' . $penduduks->gambar)); ?>" class="img-fluid mt-2 d-block " alt="<?php echo e($penduduks->statuses); ?>">
            <?php else: ?>
                <img src="https://source.unsplash.com/1200x400? <?php echo e($penduduks->statuses); ?>" class="img-fluid mt-2 d-block"
                    alt="<?php echo e($penduduks->statuses); ?>">
            <?php endif; ?>

            <article class="fs-5">
                <?php echo $penduduks->body; ?>

            </article>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/penduduk2055/view.blade.php ENDPATH**/ ?>