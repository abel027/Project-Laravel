
<?php $__env->startSection('admin-abel'); ?>
    <div class="row">
        <div class="col-lg-6">
            <form action="/dashboard/barang2055" method="post" enctype="multipart/form-data" class="tambah-barang" novalidate>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="" class="form-label">kode Barang</label>
                    <div class="input-group">
                        <span class="input-group-text" name="kode_barang" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control <?php $__errorArgs = ['hargakode_barang_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="title" id="kode_barang" value="<?php echo e(old('kode_barang')); ?>" placeholder="Kode Barang"
                            required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('kode_barang') ? $errors->first('kode_barang') : 'Silahkan isi Kode Barang!'); ?>


                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Nama Barang</label>
                    <div class="input-group">
                        <span class="input-group-text" name="nama_barang" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
                            id="nama_barang" value="<?php echo e(old('nama_barang')); ?>" placeholder="Nama Barang" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('nama_barang') ? $errors->first('nama_barang') : 'Silahkan isi Kode Barang!'); ?>


                        </div>
                    </div>
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Tipe Barang</label>
                    <select class="form-select form-select-md" name="tipe_barang" id="">
                        <?php $__currentLoopData = $tipe_barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('tipe_barang') == $item->id ? 'selected' : ''); ?>> 
                                <?php echo e($item->nama_tipe); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Tanggal Expired</label>
                    <div class="input-group">
                        <span class="input-group-text" name="tgl_exp" id="basic-addon1"><span
                                data-feather="calendar"></span></span>
                        <input type="date" class="form-control  <?php $__errorArgs = ['tgl_exp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('tgl_exp')); ?>" name="tgl_exp" id="tgl_exp" placeholder="tgl_exp2020" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('tgl_exp') ? $errors->first('tgl_exp') : 'Silahkan isi tgl_exp2020!'); ?>


                        </div>
                    </div>
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Harga Beli</label>
                    <div class="input-group">
                        <span class="input-group-text" name="harga_beli" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control <?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
                            id="harga_beli" value="<?php echo e(old('harga_beli')); ?>" placeholder="Harga beli" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('harga_beli') ? $errors->first('harga_beli') : 'Silahkan isi Kode Barang!'); ?>


                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Harga Jual</label>
                    <div class="input-group">
                        <span class="input-group-text" name="harga_jual" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
                            id="harga_jual" value="<?php echo e(old('harga_jual')); ?>" placeholder="Harga Jual" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('harga_jual') ? $errors->first('harga_jual') : 'Silahkan isi Kode Barang!'); ?>


                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Stok</label>
                    <div class="input-group">
                        <span class="input-group-text" name="stok" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
                            id="stok" value="<?php echo e(old('stok')); ?>" placeholder="Stok" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('stok') ? $errors->first('stok') : 'Silahkan isi Kode Barang!'); ?>


                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Pilih Gambar</label>
                    <img src="" id="img-preview" class="img-preview img-fluid w-50 mb-3" alt="">
                    <input type="file" onchange="previewImage()"
                        class="form-control <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*" name="gambar"
                        id="gambar" placeholder="" aria-describedby="fileHelpId">
                    <div id="fileHelpId" class="form-text text-danger">Format jpg,jpeg,png</div>
                    <div class="invalid-feedback">
                        <?php echo e($errors->has('gambar') ? $errors->first('gambar') : ''); ?>


                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Kondisi</label>
                        <div>
                            <div class="form-check">
                                <label for="" class="form-label">Masih di Jual</label>
                                <input class="form-check-input" type="radio" name="kondisi" id="kondisi">
                            </div>
                            <div class="form-check">
                                <label for="" class="form-label">Tidak di Jual</label>
                                <input class="form-check-input" type="radio" name="kondisi" id="kondisi" checked>
                            </div>
                        </div>
                    </div>


                    <div class="mb-3">
                        <label for="" class="form-label">Keterangan</label>
                        <input type="text" id="x"
                            class="form-control d-none <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="keterangan"
                            value="<?php echo e(old('keterangan')); ?>" required>
                        <trix-editor input="x"></trix-editor>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('keterangan') ? $errors->first('keterangan') : 'Silahkan isi keterangan!'); ?>


                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">SIMPAN</button>


            </form>
        </div>
    </div>
    <script>
        (() => {
            'use strict'
    
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.tambah-barang')
    
            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
    
                    form.classList.add('was-validated')
                }, false)
            })
        })()

        const kode_barang = document.getElementById('kode_barang');
        const slug = document.getElementById('slug');
        title.addEventListener('change', function() {
            fetch('/dashboard/barang2055/checkSlug?title=' + kode_barang.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        });
    
        //fungsi preview gambar
        function previewImage(){
            const image=document.getElementById('gambar');
            const imgPreview = document.getElementById('img-preview');
    
            imgPreview.style.display = 'block';
            const ofReader = new FileReader();
            ofReader.readAsDataURL(image.files[0]);
            ofReader.onload=function(ofREvent){
                imgPreview.src = ofREvent.target.result;
        }
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/barang2055/create.blade.php ENDPATH**/ ?>