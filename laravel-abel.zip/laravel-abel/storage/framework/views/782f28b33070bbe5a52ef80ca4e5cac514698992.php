<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello</title>
</head>
<body>
    <h1>Informasi Detail</h1>
    Nama : <?php echo e($nama); ?> <br>
    No Bp : <?php echo e($no_bp); ?> <br>
    Prodi : <?php echo e($prodi); ?> 
</body>
</html><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/hello.blade.php ENDPATH**/ ?>