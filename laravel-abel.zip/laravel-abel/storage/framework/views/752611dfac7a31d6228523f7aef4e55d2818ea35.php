<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($active === 'page' ? 'active' : ''); ?>" aria-current="page"
                        href="/">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e($active === 'about-me' ? 'active' : ''); ?>" href="/about-me">About Me</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e($active === 'post' ? 'active' : ''); ?>" href="/post">Post</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e($active === 'student' ? 'active' : ''); ?>" href="/student">Mahasiswa</a>
                </li>

                <!--<li class="nav-item">
          <a class="nav-link <?php echo e($active === 'pekerja2060' ? 'active' : ''); ?>" href="/student">Pekerja</a>
        </li>-->
            </ul>

            <ul class="navbar-nav">
                <!-- Kondisi sudah login -->
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <i class="bi bi-person-circle"></i> Welcome, <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li>
                                <form action="/logout" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">
                                        <i class="bi bi-box-arrow-in-right"></i> Log Out</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <!-- Kondisi sebelum Login -->
                    <li>
                        <a href="/login" class="nav-link <?php echo e($active === 'login' ? 'active' : ''); ?>">
                            <i class="bi bi-box-arrow-right"></i> Login</a>
                    </li>
                <?php endif; ?>
            </ul>



        </div>
    </div>
</nav>
<?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/partials/nav.blade.php ENDPATH**/ ?>