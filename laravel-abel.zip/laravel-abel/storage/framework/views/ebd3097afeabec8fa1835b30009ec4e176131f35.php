
<?php $__env->startSection('admin-nauval'); ?>
    <div class="row">
        <div class="col-lg-6">
            <form action="/dashboard/post" method="post" enctype="multipart/form-data" class="tambah-post" novalidate>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="" class="form-label">Title</label>
                    <div class="input-group">
                        <span class="input-group-text" name="title" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title"
                            id="title" value="<?php echo e(old('title')); ?>" placeholder="Title" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('title') ? $errors->first('title') : 'Silahkan isi Title!'); ?>


                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Slug</label>
                    <div class="input-group">
                        <span class="input-group-text" name="slug" id="basic-addon1"><span
                                data-feather="align-left"></span></span>
                        <input type="text" class="form-control  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('slug')); ?>" name="slug" id="slug" placeholder="Slug" required>
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('slug') ? $errors->first('slug') : 'Silahkan isi Slug!'); ?>


                        </div>
                    </div>
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Kategori</label>
                    <select class="form-select form-select-md" name="category_id" id="">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('category_id') == $item->id ? 'selected' : ''); ?>> <?php echo e($item->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Excerpt</label>
                    <textarea class="form-control  <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name="excerpt" id=""
                         rows="3" required><?php echo e(old('excerpt')); ?></textarea>
                    <div class="invalid-feedback">
                        <?php echo e($errors->has('excerpt') ? $errors->first('excerpt') : 'Silahkan isi Excerpt!'); ?>


                    </div>
                </div>

                <div class="mb-3">
                  <label for="" class="form-label">Pilih Gambar</label>
                  <img src="" id="img-preview" class="img-preview img-fluid w-50 mb-3" alt="">
                  <input type="file" onchange="previewImage()" class="form-control <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*" name="gambar" id="gambar" placeholder="" aria-describedby="fileHelpId">
                  <div id="fileHelpId" class="form-text text-danger">Format jpg,jpeg,png</div>
                  <div class="invalid-feedback">
                    <?php echo e($errors->has('gambar') ? $errors->first('gambar') : ''); ?>


                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Body</label>
                    <input type="text" id="x" class="form-control d-none <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "
                        name="body" value="<?php echo e(old('body')); ?>" required>
                    <trix-editor input="x"></trix-editor>
                    <div class="invalid-feedback">
                        <?php echo e($errors->has('body') ? $errors->first('body') : 'Silahkan isi Body!'); ?>


                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-3">SIMPAN</button>

            </form>
        </div>
    </div>
    <script>
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.tambah-post')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
        ///dashboard/post/checkSlug?title=Judul%20Pertama
        //slug -> judul-pertama
        const title = document.getElementById('title');
        const slug = document.getElementById('slug');
        title.addEventListener('change', function() {
            fetch('/dashboard/post/checkSlug?title=' + title.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        });

        //fungsi preview gambar
        function previewImage(){
            const image=document.getElementById('gambar');
            const imgPreview = document.getElementById('img-preview');

            imgPreview.style.display = 'block';
            const ofReader = new FileReader();
            ofReader.readAsDataURL(image.files[0]);
            ofReader.onload=function(ofREvent){
                imgPreview.src = ofREvent.target.result;
            }
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/dashboard/post/create.blade.php ENDPATH**/ ?>