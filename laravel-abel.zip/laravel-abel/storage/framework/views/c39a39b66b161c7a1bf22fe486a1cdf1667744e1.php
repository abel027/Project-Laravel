
<?php $__env->startSection('admin-abel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <strong>Info</strong> <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-8">
            <a href="/dashboard/administrasi2055/create" class="btn btn-success"><span data-feather='plus-circle'></span>
                Tambah</i></a>
        </div>
        <div class="col-lg-4">
            <form action="/dashboard/administrasi2055" method="get">
                <div class="input-group flex-nowrap">
                    <input type="text" class="form-control" placeholder="Cari" name="search"
                        value="<?php echo e(request('search')); ?>" aria-label="Username" aria-describedby="addon-wrapping">
                    <button type="submit" class="input-group-text btn btn-outline-success"><span
                            data-feather="search"></span></button>
                </div>
            </form>
        </div>
    </div>

    <!-- jika data ditemukan  atau data tersedia -->

    <div class="table-responsive-lg">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">NIP</th>
                    <th scope="col">Nama</th>
                    <th scope="col">NoTlp</th>
                    <th scope="col">Golongan</th>
                    <th scope="col">Action</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $administrasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        <td scope="row"><?php echo e($administrasis->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($item->nonip); ?></td>
                        <td><?php echo e($item->name); ?></td>    
                        <td><?php echo e($item->notlp); ?></td> 
                        <td><?php echo e($item->golongan2055->golongan); ?></td>

                        <td>
                            <a href="/dashboard/administrasi2055/<?php echo e($item->nonip); ?>/edit" class="badge bg-primary"><span
                                    data-feather="edit"></span></a>
                                <form action="/dashboard/administrasi2055/<?php echo e($item->nonip); ?>" method="post" class="d-inline  ">
                                    <!-- Timpa method Post menjadi delete -->
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        onclick="return confirm('Apakah anda yakin Ingin hapus ? <?php echo e($item->name); ?>')"
                                        class="badge bg-danger border-0">
                                        <span data-feather="x-circle"></span>
                                    </button>
                                </form>
                

                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end">
        <!--Menampilkan page/halaman-->
        <?php echo e($administrasis->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/administrasi2055/index.blade.php ENDPATH**/ ?>