
<?php $__env->startSection('admin-abel'); ?>
    <div class="row">
        <div class="col-lg-7">
            <form action="/dashboard/penduduk2055" method="post" enctype="multipart/form-data" class="tambah-penduduk"
                novalidate>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="" class="form-label">Nama</label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><span data-feather="type"></span></span>
                        <input type="text" required class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="name" id="name" placeholder="Nama" value="<?php echo e(old('name')); ?>">
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('name') ? $errors->first('name') : 'Silahkan Isi Nama.'); ?>

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">No KTP</label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><span data-feather="type"></span></span>
                        <input type="text" required class="form-control <?php $__errorArgs = ['noktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="noktp" id="noktp" placeholder="noktp" value="<?php echo e(old('noktp')); ?>">
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('noktp') ? $errors->first('noktp') : 'Silahkan Isi No KTP.'); ?>

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jenis Kelamin</label>
                    <div class="form-check">
                        <input <?php $__errorArgs = ['jenkel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> required class="form-check-input " type="radio"
                            name="jenkel" value="Laki - Laki" <?php echo e(old('jenkel') == 'Laki - Laki' ? 'checked' : ''); ?>>
                        <label class="form-check-label">Laki - Laki</label>
                    </div>
                    <div class="form-check">
                        <input <?php $__errorArgs = ['jenkel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> required class="form-check-input" type="radio"
                            name="jenkel" value="Perempuan" <?php echo e(old('jenkel') == 'Perempuan' ? 'checked' : ''); ?>>
                        <label class="form-check-label">Perempuan</label>
                    </div>

                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Tempat Lahir</label>
                    <textarea required class="form-control <?php $__errorArgs = ['tempat_lhr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tempat_lhr" id=""
                        rows="3"><?php echo e(old('tempat_lhr')); ?></textarea>
                    <div class="invalid-feedback">
                        <?php echo e($errors->has('tempat_lhr') ? $errors->first('tempat_lhr') : 'Silahkan isi Tempat Lahir.'); ?>

                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Tanggal Lahir</label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><span data-feather="at-sign"></span></span>
                        <input type="date" required class="form-control <?php $__errorArgs = ['tgl_lhr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="tgl_lhr" id="tgl_lhr" placeholder="Tanggal Lahir" value="<?php echo e(old('tgl_lhr')); ?>">
                        <div class="invalid-feedback">
                            <?php echo e($errors->has('tgl_lhr') ? $errors->first('tgl_lhr') : 'Silahkan Isi Tanggal Lahir.'); ?>

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Status</label>
                    <select class="form-select form-select-md" name="status2055_id" id="status2055_id">
                        <?php $__currentLoopData = $status2055; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('status2055_id') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="agama" class="form-label">Agama</label>
                    <select class="form-select form-select-md" name="agama" id="agama">
                        <option value="Islam">Islam</option>
                        <option value="Kristen">Kristen</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Budha">Budha</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Foto KTP</label>
                    <img src="" id="img-preview" class="img-preview img-fluid w-50 mb-2" alt="">
                    <input type="file" onchange="previewImage()"
                        class="form-control <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required accept="image/*" name="gambar"
                        id="gambar" placeholder="" aria-describedby="fileHelpId">
                    <div id="fileHelpId" class="form-text text-danger">Format jpg,jpeg,png</div>
                    <div class="invalid-feedback">
                        <?php echo e($errors->has('gambar') ? $errors->first('gambar') : 'Silahkan isi Foto Ktp.'); ?>

                    </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">SAVE</button>

            </form>
        </div>
    </div>
    <script>
        // Example starter JavaScript for disabling form submissions if there are invalid fields
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.tambah-penduduk')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()

        //fungsi preview gambar//
        function previewImage() {
            const image = document.getElementById('gambar');
            const imgPreview = document.getElementById('img-preview');

            imgPreview.style.display = 'block';
            const ofReader = new FileReader();
            ofReader.readAsDataURL(image.files[0]);
            ofReader.onload = function(oFREvent) {
                imgPreview.src = oFREvent.target.result;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/penduduk2055/create.blade.php ENDPATH**/ ?>