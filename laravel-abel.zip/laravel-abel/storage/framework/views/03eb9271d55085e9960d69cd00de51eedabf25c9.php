<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hello</title>
</head>
<body>
    <h1>Informasi Perkuliahan <?php echo e($matkul); ?></h1>
    <ol>
        <li>Jam dan Hari : <?php echo e($jam_hari); ?></li>
        <li>Lokal/Labor : <?php echo e($labor); ?></li>
        <li>Kelas : <?php echo e($kelas); ?></li>
    </ol>
</body>
</html><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/2060.blade.php ENDPATH**/ ?>