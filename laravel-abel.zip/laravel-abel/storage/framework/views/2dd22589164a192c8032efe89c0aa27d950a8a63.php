

<?php $__env->startSection('admin-abel'); ?>

 <h1>Berikut Halaman Index Category</h1>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/dashboard/category/index.blade.php ENDPATH**/ ?>