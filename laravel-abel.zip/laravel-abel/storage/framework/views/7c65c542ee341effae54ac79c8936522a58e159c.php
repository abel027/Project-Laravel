

    <?php $__env->startSection('Muhammad-Abbel'); ?>
        <h1>Halaman Home</h1>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SMT 4\PAK RONI\PHP\FRAMEWORK\Apps\laravel-abel\resources\views/home.blade.php ENDPATH**/ ?>