
<?php $__env->startSection('Nauval-Maulana'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1> <?php echo e($post->title); ?></h1>
            <h5>
                By : <a href="/post/users/<?php echo e($post->author->username); ?>" class="text-decoration-none">
                    <?php echo e($post->author->name); ?></a>,
                In <a href="/post/categories/<?php echo e($post->category->slug); ?>" class="text-decoration-none"> 
                    <?php echo e($post->category->name); ?></a>
                <?php echo e($post->created_at->diffForHumans()); ?>

            </h5>
            <img src="https://source.unsplash.com/1200x500? <?php echo e($post->category->name); ?>" class="img-fluid" 
                alt="<?php echo e($post->category->name); ?>">
            <article class="mt-3 fs-5">
                <?php echo $post->body; ?>

            </article>
            <a href="/post">Kembali ke Halaman Berita</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web Framework\Apps\laravel-nauval\resources\views/post/single.blade.php ENDPATH**/ ?>