@extends('layouts.main')

    @section('Muhammad-Abbel')
        <h1>Halaman Home</h1>
    @endsection