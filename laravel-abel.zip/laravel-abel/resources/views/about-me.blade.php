<!--agar terhubung ke folder layouts-->
@extends('layouts.main')

@section('Muhammad-Abbel')
    <h3>Nama Lengkap : {{ $nama }}</h3> 
    <h3>No.Bp : {{ $no_bp }}</h3> 
    <h3>Email : {{ $email }}</h3> 
    <p>
        <img src="/images/{{ $gambar }}" alt="{{ $nama }}" class="rounded-circle" width="80">
    </p>
@endsection