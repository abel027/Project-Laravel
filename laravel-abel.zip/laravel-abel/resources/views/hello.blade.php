<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=h1, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Informasi Detail</h1>
    Nama  : <?= $nama ?><br>
    No BP : <?= $no_bp ?><br>
    Prodi : <?= $prodi ?>
</body>
</html>