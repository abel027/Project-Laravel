<!--agar terhubung ke folder layouts-->
@extends('layouts.main')

@section('Muhammad-Abbel')
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Gambar</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($mhs as $item)
                <tr class="">
                    <td scope="row">{{ $loop->iteration }}</td>
                    <td>{{ $item->nim }}</td>
                    <td>{{ $item->nama }}</td>
                    <td>{{ $item->jurusan->name_jurusan }}</td>

                    <td>
                        <img src="/images/mhs/{{ $item->gambar }}" alt="{{ $item->nim }}" class="img-thumbnail rounded-circle" width="90">
                    </td>
                    <td>
                        <a href="/student/{{ $item['nim'] }}" class="btn btn-warning"> Detail </a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection