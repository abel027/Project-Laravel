<!--agar terhubung ke folder layouts-->
@extends('layouts.main')
@section('Muhammad-Abbel')
<h3 class="text-center">{{ $title }}</h3>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="/student" method="get">

                <div class="input-group mb-3">
                    <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Search">
                    <button class="btn btn-success" type="submit">Seacrh</button>
                </div>
            </form>
        </div>
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">NIM</th>
                <th scope="col">Nama</th>
                <th scope="col">Jurusan</th>
                <th scope="col">Gambar</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($mhs as $item)
                <tr class="">
                    <td scope="row">{{ $loop->iteration }}</td>
                    <td>{{ $item->nim }}</td>
                    <td>{{ $item->nama }}</td>
                    <td>
                        <a href="/student?jurusan={{ $item->jurusan->slug }}"> {{ $item->jurusan->name_jurusan }}</td>
                    <td>
                        <img src="/images/mhs/{{ $item->gambar }}" alt="{{ $item['nim'] }}" class="img-thumbnail rounded-circle" width="90">
                    </td>
                    <td>
                        <a href="/student/{{ $item->nim }}" class="btn btn-warning"> Detail </a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection