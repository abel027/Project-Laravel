@extends('layouts.main')

@section('Muhammad-Abbel')
    <article>
        <p>NIM : {{ $student->nim }}</p>
        <p>Nama : {{ $student->nama }}</p>
        <p>No. Telpon : {{ $student->no_telpn }}</p>
        <p>Alamat : {{ $student->alamat }}</p>
        <P>Jurusan : <a href="/student/jurusans/{{ $student->jurusan->slug }}"> {{ $student->jurusan->name_jurusan }}</a></P>
        <p>Gambar : </p>
        <p>
            <img src="/images/mhs/{{ $student->gambar }}" alt="{{ $student['nim'] }}" class="img-thumbnail rounded-circle" width="90">
        </p>

        <a href="/student">Kembali Ke Halaman Utama</a>
    </article>
@endsection