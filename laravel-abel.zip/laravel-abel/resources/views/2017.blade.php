<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hello</title>
</head>
<body>
    <h1>Informasi Perkuliahan {{$matkul}}</h1>
    <ol>
        <li>Jam hari:{{ $jam_hari}} <br></li>
        <li>Labor/lokal:{{ $labor}} <br></li>
        <li>Kelas:{{ $kelas}} <br></li>
    </ol>

</body>
</html>