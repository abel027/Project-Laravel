
@extends('dashboard.layouts.main')
@section('admin-abel')

 <h1>Berikut Halaman Index Category</h1>


@endsection