@extends('dashboard.layouts.main')
@section('admin-abel')
    <div class="row">
        <div class="col-lg-12">
            @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <strong>Info</strong> {{ session('success') }}
                </div>
            @endif
        </div>
        <div class="col-lg-8">
            <a href="/dashboard/administrasi2055/create" class="btn btn-success"><span data-feather='plus-circle'></span>
                Tambah</i></a>
        </div>
        <div class="col-lg-4">
            <form action="/dashboard/administrasi2055" method="get">
                <div class="input-group flex-nowrap">
                    <input type="text" class="form-control" placeholder="Cari" name="search"
                        value="{{ request('search') }}" aria-label="Username" aria-describedby="addon-wrapping">
                    <button type="submit" class="input-group-text btn btn-outline-success"><span
                            data-feather="search"></span></button>
                </div>
            </form>
        </div>
    </div>

    <!-- jika data ditemukan  atau data tersedia -->

    <div class="table-responsive-lg">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">NIP</th>
                    <th scope="col">Nama</th>
                    <th scope="col">NoTlp</th>
                    <th scope="col">Golongan</th>
                    <th scope="col">Action</th>

                </tr>
            </thead>
            <tbody>
                @foreach ($administrasis as $item)
                    <tr class="">
                        <td scope="row">{{ $administrasis->firstItem() + $loop->index }}</td>
                        <td>{{ $item->nonip }}</td>
                        <td>{{ $item->name }}</td>    
                        <td>{{ $item->notlp }}</td> 
                        <td>{{ $item->golongan2055->golongan }}</td>

                        <td>
                            <a href="/dashboard/administrasi2055/{{ $item->nonip }}/edit" class="badge bg-primary"><span
                                    data-feather="edit"></span></a>
                                <form action="/dashboard/administrasi2055/{{ $item->nonip }}" method="post" class="d-inline  ">
                                    <!-- Timpa method Post menjadi delete -->
                                    @method('delete')
                                    @csrf
                                    <button type="submit"
                                        onclick="return confirm('Apakah anda yakin Ingin hapus ? {{ $item->name }}')"
                                        class="badge bg-danger border-0">
                                        <span data-feather="x-circle"></span>
                                    </button>
                                </form>
                

                        </td>

                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end">
        <!--Menampilkan page/halaman-->
        {{ $administrasis->links() }}
    </div>
@endsection
