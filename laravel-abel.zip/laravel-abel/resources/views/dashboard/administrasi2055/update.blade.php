@extends('dashboard.layouts.main')
@section('admin-abel')
    <div class="row">
        <div class="col-lg-7">
            <form action="/dashboard/administrasi2055" method="post" enctype="multipart/form-data" class="update-adm"
                novalidate>
                @csrf
                <div class="mb-3">
                    <label for="" class="form-label">NIP</label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><span data-feather="type"></span></span>
                        <input type="text" required class="form-control @error('nonip') is-invalid @enderror"
                            name="nonip" id="nonip" placeholder="nonip" value="{{ old('nonip') }}">
                        <div class="invalid-feedback">
                            {{ $errors->has('nonip') ? $errors->first('nonip') : 'Silahkan Isi No NIP.' }}
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Nama</label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><span data-feather="type"></span></span>
                        <input type="text" required class="form-control @error('name') is-invalid @enderror"
                            name="name" id="name" placeholder="Nama" value="{{ old('name') }}">
                        <div class="invalid-feedback">
                            {{ $errors->has('name') ? $errors->first('name') : 'Silahkan Isi Nama.' }}
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">No Tlp</label>
                    <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><span data-feather="type"></span></span>
                        <input type="text" required class="form-control @error('notlp') is-invalid @enderror"
                            name="notlp" id="notlp" placeholder="notlp" value="{{ old('notlp') }}">
                        <div class="invalid-feedback">
                            {{ $errors->has('notlp') ? $errors->first('notlp') : 'Silahkan Isi notlp.' }}
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Jenis Kelamin</label>
                    <div class="form-check">
                        <input @error('jenkel') is-invalid @enderror required class="form-check-input " type="radio"
                            name="jenkel" value="Laki - Laki" {{ old('jenkel') == 'Laki - Laki' ? 'checked' : '' }}>
                        <label class="form-check-label">Laki - Laki</label>
                    </div>
                    <div class="form-check">
                        <input @error('jenkel') is-invalid @enderror required class="form-check-input" type="radio"
                            name="jenkel" value="Perempuan" {{ old('jenkel') == 'Perempuan' ? 'checked' : '' }}>
                        <label class="form-check-label">Perempuan</label>
                    </div>

                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Alamat</label>
                    <textarea required class="form-control @error('alamat') is-invalid @enderror" name="alamat" id=""
                        rows="3">{{ old('alamat') }}</textarea>
                    <div class="invalid-feedback">
                        {{ $errors->has('alamat') ? $errors->first('alamat') : 'Silahkan isi Tempat Lahir.' }}
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Golongan</label>
                    <select class="form-select form-select-md" name="golongan2055_id" id="golongan2055_id">
                        @foreach ($golongan2055 as $item)
                            <option value="{{ $item->id }}" {{ old('golongan2055_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->golongan }}</option>
                        @endforeach
                    </select>
                </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">SAVE</button>

            </form>
        </div>
    </div>
    <script>
        // Example starter JavaScript for disabling form submissions if there are invalid fields
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.update-adm')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()

        //fungsi preview gambar//
        function previewImage() {
            const image = document.getElementById('gambar');
            const imgPreview = document.getElementById('img-preview');

            imgPreview.style.display = 'block';
            const ofReader = new FileReader();
            ofReader.readAsDataURL(image.files[0]);
            ofReader.onload = function(oFREvent) {
                imgPreview.src = oFREvent.target.result;
            }
        }
    </script>
@endsection
