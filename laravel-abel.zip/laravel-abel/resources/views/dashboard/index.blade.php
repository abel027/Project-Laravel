@extends('dashboard.layouts.main')
@section('admin-abel')
    Halaman Dashboard
@endsection