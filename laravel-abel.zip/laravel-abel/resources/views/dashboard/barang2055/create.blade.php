@extends('dashboard.layouts.main')
@section('admin-abel')
    <div class="row">
        <div class="col-lg-6">
            <form action="/dashboard/barang2055" method="post" enctype="multipart/form-data" class="tambah-barang" novalidate>
                @csrf
                <div class="mb-3">
                    <label for="" class="form-label">kode Barang</label>
                    <div class="input-group">
                        <span class="input-group-text" name="kode_barang" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control @error('hargakode_barang_jual') is-invalid @enderror"
                            name="title" id="kode_barang" value="{{ old('kode_barang') }}" placeholder="Kode Barang"
                            required>
                        <div class="invalid-feedback">
                            {{ $errors->has('kode_barang') ? $errors->first('kode_barang') : 'Silahkan isi Kode Barang!' }}

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Nama Barang</label>
                    <div class="input-group">
                        <span class="input-group-text" name="nama_barang" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control @error('nama_barang') is-invalid @enderror" name="title"
                            id="nama_barang" value="{{ old('nama_barang') }}" placeholder="Nama Barang" required>
                        <div class="invalid-feedback">
                            {{ $errors->has('nama_barang') ? $errors->first('nama_barang') : 'Silahkan isi Kode Barang!' }}

                        </div>
                    </div>
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Tipe Barang</label>
                    <select class="form-select form-select-md" name="tipe_barang" id="">
                        @foreach ($tipe_barangs as $item)
                            <option value="{{ $item->id }}" {{ old('tipe_barang') == $item->id ? 'selected' : '' }}> 
                                {{ $item->nama_tipe }} </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Tanggal Expired</label>
                    <div class="input-group">
                        <span class="input-group-text" name="tgl_exp" id="basic-addon1"><span
                                data-feather="calendar"></span></span>
                        <input type="date" class="form-control  @error('tgl_exp') is-invalid @enderror"
                            value="{{ old('tgl_exp') }}" name="tgl_exp" id="tgl_exp" placeholder="tgl_exp2020" required>
                        <div class="invalid-feedback">
                            {{ $errors->has('tgl_exp') ? $errors->first('tgl_exp') : 'Silahkan isi tgl_exp2020!' }}

                        </div>
                    </div>
                </div>


                <div class="mb-3">
                    <label for="" class="form-label">Harga Beli</label>
                    <div class="input-group">
                        <span class="input-group-text" name="harga_beli" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control @error('harga_beli') is-invalid @enderror" name="title"
                            id="harga_beli" value="{{ old('harga_beli') }}" placeholder="Harga beli" required>
                        <div class="invalid-feedback">
                            {{ $errors->has('harga_beli') ? $errors->first('harga_beli') : 'Silahkan isi Kode Barang!' }}

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Harga Jual</label>
                    <div class="input-group">
                        <span class="input-group-text" name="harga_jual" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control @error('harga_jual') is-invalid @enderror" name="title"
                            id="harga_jual" value="{{ old('harga_jual') }}" placeholder="Harga Jual" required>
                        <div class="invalid-feedback">
                            {{ $errors->has('harga_jual') ? $errors->first('harga_jual') : 'Silahkan isi Kode Barang!' }}

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Stok</label>
                    <div class="input-group">
                        <span class="input-group-text" name="stok" id="basic-addon1"><span
                                data-feather="type"></span></span>
                        <input type="text" class="form-control @error('stok') is-invalid @enderror" name="title"
                            id="stok" value="{{ old('stok') }}" placeholder="Stok" required>
                        <div class="invalid-feedback">
                            {{ $errors->has('stok') ? $errors->first('stok') : 'Silahkan isi Kode Barang!' }}

                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Pilih Gambar</label>
                    <img src="" id="img-preview" class="img-preview img-fluid w-50 mb-3" alt="">
                    <input type="file" onchange="previewImage()"
                        class="form-control @error('gambar') is-invalid @enderror" accept="image/*" name="gambar"
                        id="gambar" placeholder="" aria-describedby="fileHelpId">
                    <div id="fileHelpId" class="form-text text-danger">Format jpg,jpeg,png</div>
                    <div class="invalid-feedback">
                        {{ $errors->has('gambar') ? $errors->first('gambar') : '' }}

                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Kondisi</label>
                        <div>
                            <div class="form-check">
                                <label for="" class="form-label">Masih di Jual</label>
                                <input class="form-check-input" type="radio" name="kondisi" id="kondisi">
                            </div>
                            <div class="form-check">
                                <label for="" class="form-label">Tidak di Jual</label>
                                <input class="form-check-input" type="radio" name="kondisi" id="kondisi" checked>
                            </div>
                        </div>
                    </div>


                    <div class="mb-3">
                        <label for="" class="form-label">Keterangan</label>
                        <input type="text" id="x"
                            class="form-control d-none @error('keterangan') is-invalid @enderror " name="keterangan"
                            value="{{ old('keterangan') }}" required>
                        <trix-editor input="x"></trix-editor>
                        <div class="invalid-feedback">
                            {{ $errors->has('keterangan') ? $errors->first('keterangan') : 'Silahkan isi keterangan!' }}

                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">SIMPAN</button>


            </form>
        </div>
    </div>
    <script>
        (() => {
            'use strict'
    
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.tambah-barang')
    
            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }
    
                    form.classList.add('was-validated')
                }, false)
            })
        })()

        const kode_barang = document.getElementById('kode_barang');
        const slug = document.getElementById('slug');
        title.addEventListener('change', function() {
            fetch('/dashboard/barang2055/checkSlug?title=' + kode_barang.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        });
    
        //fungsi preview gambar
        function previewImage(){
            const image=document.getElementById('gambar');
            const imgPreview = document.getElementById('img-preview');
    
            imgPreview.style.display = 'block';
            const ofReader = new FileReader();
            ofReader.readAsDataURL(image.files[0]);
            ofReader.onload=function(ofREvent){
                imgPreview.src = ofREvent.target.result;
        }
    }
    </script>
@endsection
