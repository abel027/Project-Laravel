@extends('dashboard.layouts.main')
@section('admin-abel')
    <div class="row">
        <div class="col-lg-7">
            <form action="/dashboard/post/{{ $post->slug }}" method="post" class="tambah-post" enctype="multipart/form-data"
                novalidate>
                <!-- timpa method post menjadi put untuk update -->
                @method('put')
                @csrf

                <div class="mb-3">
                    <label for="" class="form-label">Title</label>
                    <div class="input-group">
                        <span class="input-group-text"><span data-feather="type"></span></span>
                        <input type="text" required class="form-control @error('title') is-invalid @enderror"
                            placeholder="Title" name="title" id="title" value="{{ old('title', $post->title) }}"
                            aria-describedby="basic-addon1">
                        <div class="invalid-feedback">
                            {{ $errors->has('title') ? $errors->first('title') : 'Silahkan Isi Title' }}
                        </div>

                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Slug</label>
                    <div class="input-group mb-3">
                        <span class="input-group-text"><span data-feather="align-left"></span></span>
                        <input type="text" required class="form-control @error('slug') is-invalid @enderror"
                            name="slug" id="slug" value="{{ old('slug', $post->slug) }}" placeholder="slug">
                        <div class="invalid-feedback">
                            {{ $errors->has('slug') ? $errors->first('slug') : 'Silahkan Isi Slug' }}
                        </div>
                    </div>
                </div>



                <div class="mb-3">
                    <label for="" class="form-label">Kategori</label>
                    <select class="form-select form-select-md" name="category_id" id="">
                        @foreach ($kategori as $item)
                            <option value="{{ $item->id }}"
                                {{ old('category_id', $post->category_id) == $item->id ? 'selected' : '' }}>
                                {{ $item->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Excerpt</label>
                    <textarea class="form-control  @error('excerpt') is-invalid @enderror " name="excerpt" id="" rows="3"
                        required>{{ old('excerpt', $post->excerpt) }}</textarea>
                    <div class="invalid-feedback">
                        {{ $errors->has('excerpt') ? $errors->first('excerpt') : 'Silahkan isi Excerpt!' }}

                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Pilih Gambar</label>
                    <img src="{{ $post->gambar ? asset('storage/' . $post->gambar) : '' }}" id="img-preview"
                        class="img-preview img-fluid w-50 mb-3 d-block" alt="">
                    <input type="hidden" name="oldImage" id="" value="{{ $post->gambar }}">
                    <input type="file" onchange="previewImage()"
                        class="form-control @error('gambar') is-invalid @enderror" accept="image/*" name="gambar"
                        id="gambar" placeholder="" aria-describedby="fileHelpId">
                    <div id="fileHelpId" class="form-text text-danger">Format jpg,jpeg,png</div>
                    <div class="invalid-feedback">
                        {{ $errors->has('gambar') ? $errors->first('gambar') : '' }}

                    </div>
                </div>

                <div class="mb-3">
                    <label for="" class="form-label">Body</label>
                    <input type="text" id="x" class="form-control d-none @error('body') is-invalid @enderror "
                        name="body" value="{{ old('body', $post->body) }}" required>
                    <trix-editor input="x"></trix-editor>
                    <div class="invalid-feedback">
                        {{ $errors->has('body') ? $errors->first('body') : 'Silahkan isi Body!' }}
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-3">Simpan</button>

            </form>

        </div>
    </div>
    <script>
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.tambah-post')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
        ///dashboard/post/checkSlug?title=Judul%20Pertama
        //slug -> judul-pertama
        const title = document.getElementById('title');
        const slug = document.getElementById('slug');
        title.addEventListener('change', function() {
            fetch('/dashboard/post/checkSlug?title=' + title.value)
                .then(response => response.json())
                .then(data => slug.value = data.slug)
        });

        //fungsi preview gambar
        function previewImage() {
            const image = document.getElementById('gambar');
            const imgPreview = document.getElementById('img-preview');

            imgPreview.style.display = 'block';
            const ofReader = new FileReader();
            ofReader.readAsDataURL(image.files[0]);
            ofReader.onload = function(ofREvent) {
                imgPreview.src = ofREvent.target.result;
            }
        }
    </script>
@endsection
