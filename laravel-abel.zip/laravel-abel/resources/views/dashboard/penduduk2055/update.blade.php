@extends('dashboard.layouts.main')
@section('admin-abel')
<div class="row">
    <div class="col-lg-7">
        <form action="/dashboard/penduduk2055/{{ $penduduk2055->noktp }}" method="post" enctype="multipart/form-data" class="update-penduduk" novalidate>
            @method('put')
            @csrf
            <div class="mb-3">
                <label for="" class="form-label">Nama</label>
                <div class="input-group">
                    <span class="input-group-text" id="basic-addon1" ><span data-feather="type"></span></span>
                    <input type="text" required class="form-control @error('name') is-invalid @enderror" 
                    name="name" id="name" placeholder="Nama" value="{{ old('name', $penduduk2055->name) }}">
                    <div class="invalid-feedback">
                        {{ $errors->has('name') ? $errors->first('name') : 'Silahkan Isi Nama.' }}
                      </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="" class="form-label">No KTP</label>
                <div class="input-group">
                    <span class="input-group-text" id="basic-addon1" ><span data-feather="type"></span></span>
                    <input type="text" required class="form-control @error('noktp') is-invalid @enderror" 
                    name="noktp" id="noktp" placeholder="noktp" value="{{ old('noktp', $penduduk2055->noktp) }}">
                    <div class="invalid-feedback">
                        {{ $errors->has('noktp') ? $errors->first('noktp') : 'Silahkan Isi No KTP.' }}
                      </div>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Jenis Kelamin</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="jenkel" value="Laki - Laki" {{ old('jenkel', $penduduk2055->jenkel) == 'Laki - Laki' ? 'checked' : '' }}>
                    <label class="form-check-label">Laki - Laki</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="jenkel" value="Perempuan" {{ old('jenkel', $penduduk2055->jenkel) == 'Perempuan' ? 'checked' : '' }}>
                    <label class="form-check-label">Perempuan</label>
                </div>
                <div class="invalid-feedback">
                    {{ $errors->has('jenkel') ? $errors->first('jenkel') : 'Silahkan Pilih Jenis Kelamin.' }}
                </div>
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Tempat Lahir</label>
                <textarea  required class="form-control @error('tempat_lhr') is-invalid @enderror" name="tempat_lhr" id="" rows="3">{{ old('tempat_lhr', $penduduk2055->tempat_lhr) }}</textarea>
                <div class="invalid-feedback">
                    {{ $errors->has('tempat_lhr') ? $errors->first('tempat_lhr') : 'Silahkan isi Tempat Lahir.'}}
                </div>
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Tanggal Lahir</label>
                <div class="input-group">
                    <span class="input-group-text" id="basic-addon1" ><span data-feather="at-sign"></span></span>
                    <input type="date" required class="form-control @error('tgl_lhr') is-invalid @enderror" 
                    name="tgl_lhr" id="tgl_lhr" placeholder="Tanggal Lahir" value="{{ old('tgl_lhr', $penduduk2055->tgl_lhr) }}">
                    <div class="invalid-feedback">
                        {{ $errors->has('tgl_lhr') ? $errors->first('tgl_lhr') : 'Silahkan Isi Tanggal Lahir.' }}
                      </div>
                </div>
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Status</label>
                <select class="form-select form-select-md" name="status2055_id" id="status2055_id">
                    @foreach ($status2055 as $item)  
                    <option value="{{ $item->id }}" {{ old('status2055_id', $penduduk2055->status2055_id) == $item->id ? 'selected' : '' }}>{{ $item->status }}</option>
                    @endforeach
                </select>
            </div>

            <div class="mb-3">
                <label for="agama" class="form-label">Agama</label>
                <select class="form-select form-select-md" name="agama" id="agama">
                    <option value="Islam" {{ old('agama',$penduduk2055->agama, $item->agama) == 'Islam' ? 'selected' : '' }}>Islam</option>
                    <option value="Kristen" {{ old('agama',$penduduk2055->agama, $item->agama) == 'Kristen' ? 'selected' : '' }}>Kristen</option>
                    <option value="Hindu" {{ old('agama',$penduduk2055->agama, $item->agama) == 'Hindu' ? 'selected' : '' }}>Hindu</option>
                    <option value="Budha" {{ old('agama',$penduduk2055->agama, $item->agama) == 'Budha' ? 'selected' : '' }}>Budha</option>
                </select>
            </div>

            <div class="mb-3"> 
                <label for="" class="form-label">Foto KTP</label>
                <img src="{{ $penduduk2055->gambar ? asset('storage/'.$penduduk2055->gambar) : ''}}" id="img-preview" class="img-preview img-fluid w-50 mb-2 d-block" alt="">
                <input type="hidden" name="oldImage" value="{{ $penduduk2055->gambar }}">
                <input type="file" onchange="previewImage()" class="form-control @error('gambar') is-invalid @enderror" accept="image/*" name="gambar" id="gambar" placeholder="" aria-describedby="fileHelpId">
                <div id="fileHelpId" class="form-text text-danger">Format jpg,jpeg,png</div>
                <div class="invalid-feedback">
                 {{ $errors->has('gambar') ? $errors->first('gambar') : 'Silahkan isi Gambar.'}}
             </div>

            <button type="submit" class="btn btn-primary w-100 mb-3">SAVE</button>

        </form>
    </div>
</div>
<script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (() => {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    const forms = document.querySelectorAll('.update-penduduk')

    // Loop over them and prevent submission
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
        }

        form.classList.add('was-validated')
        }, false)
    })
    })()

    //fungsi preview gambar//
    function previewImage(){
        const image = document.getElementById('gambar');
        const imgPreview = document.getElementById('img-preview');

        imgPreview.style.display = 'block';
        const ofReader = new FileReader();
        ofReader.readAsDataURL(image.files[0]);
        ofReader.onload = function(oFREvent){
            imgPreview.src = oFREvent.target.result;
        }
    }
</script>
    
@endsection
