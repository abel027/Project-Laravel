@extends('dashboard.layouts.main')
@section('admin-abel')
    <div class="row">
        <div class="col-lg-12">
            @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <strong>Info</strong> {{ session('success') }}
                </div>
            @endif
        </div>
        <div class="col-lg-8">
            <a href="/dashboard/penduduk2055/create" class="btn btn-success"><span data-feather='plus-circle'></span>
                Tambah</i></a>
        </div>
        <div class="col-lg-4">
            <form action="/dashboard/penduduk2055" method="get">
                <div class="input-group flex-nowrap">
                    <input type="text" class="form-control" placeholder="Cari" name="search"
                        value="{{ request('search') }}" aria-label="Username" aria-describedby="addon-wrapping">
                    <button type="submit" class="input-group-text btn btn-outline-success"><span
                            data-feather="search"></span></button>
                </div>
            </form>
        </div>
    </div>

    <!-- jika data ditemukan  atau data tersedia -->

    <div class="table-responsive-lg">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama</th>
                    <th scope="col">KTP</th>
                    <th scope="col">Status</th>
                    <th scope="col">Foto KTP</th>
                    <th scope="col">Action</th>

                </tr>
            </thead>
            <tbody>
                @foreach ($penduduks as $item)
                    <tr class="">
                        <td scope="row">{{ $penduduks->firstItem() + $loop->index }}</td>
                        <td>{{ $item->name }}</td>
                        <td>{{ $item->noktp }}</td>
                        <td>{{ $item->status2055->status }}</td>
                        <td>
                            @if ($item->gambar)
                                <img src="{{ asset('storage/' . $item->gambar) }}" class="img-fluid mt-2 d-block"
                                    width="150" alt="{{ $item->gambar }}">
                            @else
                                <img src="https://source.unsplash.com/1200x100?{{ $item->status2055->status }}"
                                    class="img-fluid mt-2" alt="{{ $item->status2055->status }}">
                            @endif
                        </td>

                        <td>
                            <a href="/dashboard/penduduk2055/{{ $item->noktp }}/edit" class="badge bg-primary"><span
                                    data-feather="edit"></span></a>
                            @can('admin')
                                <form action="/dashboard/penduduk2055/{{ $item->noktp }}" method="post" class="d-inline  ">
                                    <!-- Timpa method Post menjadi delete -->
                                    @method('delete')
                                    @csrf
                                    <button type="submit"
                                        onclick="return confirm('Apakah anda yakin Ingin hapus ? {{ $item->name }}')"
                                        class="badge bg-danger border-0">
                                        <span data-feather="x-circle"></span>
                                    </button>
                                </form>
                            @endcan

                        </td>

                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end">
        <!--Menampilkan page/halaman-->
        {{ $penduduks->links() }}
    </div>
@endsection
