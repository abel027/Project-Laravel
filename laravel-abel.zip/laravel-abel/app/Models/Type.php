<?php

namespace App\Models;

use App\Models\Barang;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Type extends Model
{
    
        use HasFactory;

        protected $guarded = ['id'];
        Protected $with = ['author'];
    
        //pencarian
        public function scopeFilter($query, array $filters)
        {
    
    
            $query->when($filters['search'] ?? false,function($query,$search){
                return 
                $query->where('type', 'like', '%'.$search.'%');
            });
    
            $query->when(
                //author berasal dari url yg di kirim
                $filters['author'] ?? false,
                fn ($query,$author) =>
                //author berasal dari relasi method public function author()
                $query->whereHas('author',
                    fn($query) =>
                    $query->where('username', $author)
                )
            );
        }
    
        //Relasi tabel categories ke Posts relasi 1 ke N//

        public function barang2055s()
        {
            return $this->hasMany(Barang::class);
        }

        public function author()
        {
            return $this->belongsTo(User::class,'id');
        }
    
        public function getRouteKeyName(){
            return 'kode';
        }
}
