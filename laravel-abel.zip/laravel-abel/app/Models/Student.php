<?php

namespace App\Models;

use App\Models\Jurusan;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Student extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
    //protected $fillable = ['nim', 'nama', 'gambar'];

    public function scopeFilter($query, array $filters)
    {
         

        $query->when
            ($filters['search']?? false,
            function($query,$search){

                return
                $query->where('nim','like','%'.$search.'%')
                    ->orWhere('nama','like','%'.$search.'%');

            });

            $query->when
                ($filters['jurusan'] ?? false,
                function($query,$jurusan){
                    return $query->whereHas('jurusan',function($query) use ($jurusan){
                        $query->where('slug',$jurusan);
                    });
            });

        }

    public function jurusan(){
        //Table Student ke Jurusans Relasi satu ke satu
        return $this->belongsTo(Jurusan::class);
    }
}
