<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jurusan extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    //Relasi tabel jurusan ke Students relasi 1 ke N//
    public function students(){
        return $this->hasMany(Student::class);
    }
}
