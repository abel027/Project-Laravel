<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    //Relasi tabel categories ke Posts relasi 1 ke N//
    public function posts(){
        return $this->hasMany(Post::class);
    }
}
