<?php
    namespace App\Models;

    class Student_{
      
        //Property method//
        private static $mhs = [
            [
                'nim'=>'2101092055',
                'nama'=>'abel',
                'no_telpn'=>'083140762311',
                'alamat'=>'Kuranji',
                'gambar'=>'pic-nauval.jpg'
            ]  
        ];

        //method all//
    public static function all(){
        //self gunakan untuk mengakses method static
        return self::$mhs;
    }

    public static function find($slug)
    {
        $mhs = static::all();
        $single_student =[];

        foreach ($mhs as $item){
        //jika key slug sama dengan parameter $slug
        if($item['nim'] == $slug){
            $single_student = $item;
            break;
        }
    }

    return $single_student;

}
}

?>
