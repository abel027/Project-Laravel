<?php
namespace App\Models;

class Post_
{
    //Property method//
    private static $posts = [
        [
            'title' => 'Judul Pertama',
            'slug' => 'Judul Pertama',
            'penulis' => 'Nauval Maulana',
            'excerpt'=> 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dolorum!',
            'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat ipsum accusantium et adipisci similique asperiores quaerat eum, debitis, veritatis iste amet, voluptate dignissimos odio! Molestiae at enim porro pariatur ipsa cupiditate ducimus. Laboriosam distinctio sequi nisi vel reiciendis asperiores id odio ullam quae necessitatibus, quasi error, magnam quis esse eaque!'
        ],
        [
            'title' => 'Judul Kedua',
            'slug' => 'Judul Kedua',
            'penulis' => 'Abel',
            'excerpt'=> 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dolorum!',
            'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat ipsum accusantium et adipisci similique asperiores quaerat eum, debitis, veritatis iste amet, voluptate dignissimos odio! Molestiae at enim porro pariatur ipsa cupiditate ducimus. Laboriosam distinctio sequi nisi vel reiciendis asperiores id odio ullam quae necessitatibus, quasi error, magnam quis esse eaque!'
        ],
        [
            'title' => 'Judul Ketiga',
            'slug' => 'Judul Ketiga',
            'penulis' => 'Apis',
            'excerpt'=> 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dolorum!',
            'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat ipsum accusantium et adipisci similique asperiores quaerat eum, debitis, veritatis iste amet, voluptate dignissimos odio! Molestiae at enim porro pariatur ipsa cupiditate ducimus. Laboriosam distinctio sequi nisi vel reiciendis asperiores id odio ullam quae necessitatibus, quasi error, magnam quis esse eaque!'
        ],
        [
            'title' => 'Judul Keempat',
            'slug' => 'Judul Keempat',
            'penulis' => 'Afad',
            'excerpt'=> 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, dolorum!',
            'body' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat ipsum accusantium et adipisci similique asperiores quaerat eum, debitis, veritatis iste amet, voluptate dignissimos odio! Molestiae at enim porro pariatur ipsa cupiditate ducimus. Laboriosam distinctio sequi nisi vel reiciendis asperiores id odio ullam quae necessitatibus, quasi error, magnam quis esse eaque!'
        ],
    ];

    //method all//
    public static function all(){
        //self gunakan untuk mengakses method static
        return collect(self::$posts);
    }

    public static function find($slug)
    {
        $posts = static::all();
        
        return $posts->firstWhere('slug',$slug);

    }
}
?>
