<?php

namespace App\Models;

use App\Models\User;
use App\Models\Administrasi2055;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Golongan2055 extends Model
{
    use HasFactory;

    protected $guarded = ['id'];
    protected $with = ['author'];

    //pencarian
    public function scopeFilter($query, array $filters)
    {


        $query->when($filters['search'] ?? false, function ($query, $search) {
            return
                $query->where('status', 'like', '%' . $search . '%');
        });

        $query->when(
            //author berasal dari url yg di kirim
            $filters['author'] ?? false,
            fn ($query, $author) =>
            //author berasal dari relasi method public function author()
            $query->whereHas(
                'author',
                fn ($query) =>
                $query->where('username', $author)
            )
        );
    }


    //relasi tabel kategori ke post
    public function administrasi2055()
    {
        return $this->hasMany(Administrasi2055::class);
    }

    public function author()
    {
        return $this->belongsTo(User::class, 'id');
    }

    public function getRouteKeyName()
    {
        return 'id';
    }
}
