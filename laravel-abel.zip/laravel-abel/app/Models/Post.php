<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Post extends Model
{
    use HasFactory;
    use Sluggable;

    protected $guarded = ['id'];
    protected $with = ['author','category'];

    //protected $fillable = ['title','excerpt','body'];

    // Tambahkan scope agar method pencarian bisa digunakan
    public function scopeFilter($query, array $filters)
    {
        $query->when($filters['search'] ?? false, function($query,$search){
            return
                $query->where('title', 'like', '%'.$search . '%')
                ->orWhere('body', 'like', '%'.$search . '%');
        });

        $query->when(
            $filters['category'] ?? false, 
            function($query,$category){
                //whereHas berasal dari relasi public function category()
                return $query->whereHas('category',function ($query) use ($category){
                    //Pencarian berdasarkan slug yang di ambil dari request category
                    $query->where('slug',$category);
                });
            }
        );

        $query->when(
            // author berasal dari url yang di kirim 
            $filters['author'] ?? false,
            fn ($query,$author) =>
            // author berasal dari relasi method public function author()
            $query->whereHas(
                'author',
                fn($query) =>
                $query->where('username', $author)
            )
        );
    }

    public function category(){

        //Tabel Posts ke categories relasi satu le satu //
        return $this->belongsTo(Category::class);
        
    }

    public function author(){

        //Tabel Posts ke categories relasi satu le satu //
        return $this->belongsTo(User::class,'user_id');
        
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }

    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title'
            ]
        ];
    }
}