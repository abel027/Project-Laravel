<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Post;
use Illuminate\Http\Request;
use Cviebrock\EloquentSluggable\Services\SlugService;
use Illuminate\Support\Facades\Storage;

class DashboardPostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('dashboard.post.index', ['title' => 'post', 'posts' => Post::where('user_id', auth()->user()->id)->latest()->filter(request(['search']))->paginate(10)->withQueryString()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    //form untuk tambah
    public function create()
    {
        return view('dashboard.post.create', ['title' => 'Tambah Post', 'kategori' => Category::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    //proses simpan data
    public function store(Request $request)
    {
        // dd($request);
        //return $request->file('gambar')->store('post-images');
        $validateData = $request->validate(
            [
                'title' => 'required|max:100|min:5',
                'slug' => 'required|unique:posts',
                'category_id' => 'required',
                'excerpt' => 'required|max:225|min:15',
                'body' => 'required|min:30',
                'gambar' => 'image|file|max:1024'
            ]
        );

        $validateData['user_id'] = auth()->user()->id;

        //jika pilih atau upload gambar//
        if ($request->file('gambar')) {
            $validateData['gambar'] = $request->file('gambar')->store('post-images');
        }

        Post::create($validateData);

        return redirect('/dashboard/post')->with('success', 'Data Post Berhasil di Simpan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        return view('dashboard.post.view', ['title' => 'view', 'post' => $post]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        return view('dashboard.post.update', ['title' => 'Edit ' . $post->title, 'post' => $post, 'kategori' => Category::all()]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    //proses update
    public function update(Request $request, Post $post)
    {
        $rules =
            [
                'title' => 'required|max:100|min:5',
                'category_id' => 'required',
                'excerpt' => 'required|max:225|min:15',
                'gambar' => 'image|file|max:1024',
                'body' => 'required|min:30'
            ];
            $validateData = $request->validate($rules);
        //jika data slug yang dikirim tidak sama dengan data slug di tabel post
        if ($request->slug != $post->slug) {
            //tambahkan validasi untuk cek apakah sudah ada atau belum
            $rules['slug'] = 'required|unique:posts';
        }
        
        if ($request->file('gambar')) {
            if ($request->oldImage) {
                Storage::delete($request->oldImage);
            }
            $validateData['gambar'] = $request->file('gambar')->store('post-images');
        }

        

        Post::where('id', $post->id)->update($validateData);
        return redirect('/dashboard/post')->with('success', 'Data Post berhasil di Update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        if ($post->gambar) {

            # code...
        }
        Post::destroy($post->id);
        return redirect('/dashboard/post')->with('success', 'Post berhasil di Simpan');
    }

    public function checkSlug(Request $request)
    {
        $slug = SlugService::createSlug(Post::class, 'slug', $request->title);
        return response()->json(['slug' => $slug]);
    }
}
