<?php

namespace App\Http\Controllers;

use App\Models\Penduduk2055;
use App\Models\Status2055;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DashboardPendudukController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()

    {
        return view('dashboard.penduduk2055.index', ['title'=>'penduduk','penduduks' => Penduduk2055::latest()->filter(request(['search']))->paginate(10)->withQueryString()]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.penduduk2055.create',['title'=>'Tambah Penduduk', 'status2055' => Status2055::all()]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request);
       
        $validateData = $request->validate
        
        (
            
            [
                'noktp' => 'required|unique:penduduk2055s',
                'name' => 'required',
                'jenkel' => 'required',
                'tempat_lhr' => 'required',
                'tgl_lhr' => 'required',
                'agama' => 'required',
                'gambar' => 'image|file|max:1024',
                'status2055_id' => 'required',  
            ]
        );

        $validateData['user_id']=auth()->user()->id;        
        //jika pilih atau upload gambar//
        if($request->file('gambar')){
            $validateData['gambar'] = $request->file('gambar')->store('penduduk2055-images');
        }

        Penduduk2055::create($validateData);
        return redirect('/dashboard/penduduk2055')->with('success','Data Penduduk Berhasil di Simpan');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Penduduk2055  $penduduk2055
     * @return \Illuminate\Http\Response
     */
    public function show(Penduduk2055 $penduduk2055)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Penduduk2055  $penduduk2055
     * @return \Illuminate\Http\Response
     */
    public function edit(Penduduk2055 $penduduk2055)
    {
        return view('dashboard.penduduk2055.update',['title'=>'edit '.$penduduk2055->title, 'penduduk2055'=>$penduduk2055, 'status2055' => Status2055::all()]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Penduduk2055  $penduduk2055
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Penduduk2055 $penduduk2055)
    {
        $rules =
            [
                'name' => 'required',
                'jenkel' => 'required',
                'tempat_lhr' => 'required',
                'tgl_lhr' => 'required',
                'agama' => 'required',
                'gambar' => 'image|file|max:1024',
                'status2055_id' => 'required', 
            ];

        //jika data slug yang kirim tidak sama dengan data slug di table post
        if($request->noktp != $penduduk2055->noktp){
            //tambahkan validasi untuk cek apakah sudah ada atau belum// 
            $rules['noktp']= 'required|unique:penduduk2055s';
        }
        $validateData = $request->validate($rules);
        //return $request->file('gambar');
        if ($request->file('gambar')) {
            if ($request->oldImage) {
               Storage::delete($request->oldImage);
            }
            $validateData['gambar'] = $request->file('gambar')->store('penduduk2055-images');
        }

       Penduduk2055::where('id',$penduduk2055->id)->update($validateData);
       return redirect('/dashboard/penduduk2055')->with('success', 'Data barang Berhasil di Update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Penduduk2055  $penduduk2055
     * @return \Illuminate\Http\Response
     */
    public function destroy(Penduduk2055 $penduduk2055)
    {
        if ($penduduk2055->gambar) {
            Storage::delete($penduduk2055->gambar);
        }
        Penduduk2055::destroy($penduduk2055->id);
        return redirect('/dashboard/penduduk2055')->with('success','Penduduk Berhasil di Hapus');
    }
}
