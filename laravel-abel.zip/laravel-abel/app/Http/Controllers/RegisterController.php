<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    //
    public function index()
    {
        return view('register.index', ['title' => 'Register', 'active' => 'login']);
    }

    //menyimpan user yang registrasi
    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required|min:2|max:100',
            'username' => ['required', 'min:4', 'max:100', 'unique:users'],
            'email' => 'required|email:dns|unique:users',
            'password' => 'required|min:6|max:200'
        ]);

        //password di enkripsi//
        $validate['password'] = bcrypt($validate['password']);

        //insert data user//
        User::create($validate);
        return redirect('/login')->with('status', 'Register Berhasil');
        //dd('Register berhasil');//
    }
}
