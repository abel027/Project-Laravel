<?php
    
    namespace App\Http\Controllers;
    use App\Models\Student;
    use App\Models\Jurusan;

    class StudentController extends Controller
    {
        //method
        public function index(){
            $title = "Student";
            if(request('jurusan')){
                $jurusan = Jurusan::firstWhere('slug',request('jurusan'));
                $title = "Jurusan :$jurusan->name_jurusan";
            }

            
            return view('student.index',['mhs'=> Student::latest()->filter(request(['search','jurusan']))
            ->get(),'title' => $title,'active' => 'student']);
        }

        //method
        public function single(Student $student){
            return view('student.single', ['student'=>$student,'title' => 'Detail Mahasiswa','active' => 'student']);
        }
    }

?>