<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\User;
use App\Models\Category;

class PostController extends Controller
{
    public function index()
    {
        //dd(Request('search'));
        //$post = Post::latest();

        $title = "";
        if(request('category')){
            $category = Category::firstWhere('slug', request('category'));
        }
        if(request('author')) {
            $author = User::firstWhere('username',request('author'));
            $title = "By : $author->name";
        }
        
        //filter berasal dari method scopefilter
        return view('post.index', ['data_posts' => Post::latest()->filter(request(['search','category','author']))->paginate(7),'title' => $title , 'active' => 'post']);
    }

    //$post harus sama dengan parameter yang ada di router web
    public function single(Post $post)
    {
        return view('post.single', ['post' =>$post, 'title' => 'single Post', 'active' => 'post']);
    }

    public function userPost(Post $post)
    {
        return view('post.single', ['post' =>$post, 'title' => 'single Post', 'active' => 'post']);

        }    
    }

?>