<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Type;
use App\Models\User;
use App\Models\Barang;
use App\Models\Category;
use Illuminate\Http\Request;

class BarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        {
            $this->authorize('admin');
            //return view('dashboard.barang2055.index', ['title' => 'Halaman Barang']);

            return view('dashboard.barang2055.index',['title'=>'Halaman barang','barang2055s' => Barang::where('user_id', auth()->user()->id)->latest()]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('dashboard.barang2055.create', ['title' => 'Tambah Barang','tipe_barangs' => Type::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = $request->validate(
            [ 
              'kode_barang' => 'required',
              'nama_barang' => 'required',
              'tgl_exp' => 'date',
              'harga_beli' => 'required',
              'harga_jual' => 'required',
              'stok' => 'required|max:100|min:1',
              'gambar' => 'image|file|max:1024',
              'kondisi' => 'required',
              'keterangan' => 'required',

            ]
        );

        $validateData['user_id'] = auth()->user()->id;

       Barang::create($validateData);

       return redirect('/dashboard/barang2055')->with('success','Data Barang Berhasil di Simpan');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return view('dashboard.barang2055.view', ['title' => 'view']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        return view('dashboard.barang2055.update', ['title' => 'Edit ']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
