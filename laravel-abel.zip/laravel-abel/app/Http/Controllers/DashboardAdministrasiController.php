<?php

namespace App\Http\Controllers;

use App\Models\Golongan2055;
use Illuminate\Http\Request;
use App\Models\Administrasi2055;
use Illuminate\Support\Facades\Storage;

class DashboardAdministrasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard.administrasi2055.index', ['title'=>'administrasi','administrasis' => Administrasi2055::latest()->filter(request(['search']))->paginate(10)->withQueryString()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.administrasi2055.create',['title'=>'Tambah Administrasi', 'golongan2055' => Golongan2055::all()]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $validateData = $request->validate
        
        (
            
            [
                'nonip' => 'required|unique:administrasi2055s',
                'name' => 'required',
                'notlp' => 'required',
                'jenkel' => 'required',
                'alamat' => 'required',
                'golongan2055_id' => 'required',  
            ]
        );

        $validateData['user_id']=auth()->user()->id;        

        Administrasi2055::create($validateData);
        return redirect('/dashboard/administrasi2055')->with('success','Data Administrasi Berhasil di Simpan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Administrasi2055 $administrasi2055)
    {
        //
        return view('dashboard.administrasi2055.update',['title'=>'edit '.$administrasi2055->title, 'administrasi2055'=>$administrasi2055, 'golongan2055' => Golongan2055::all()]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Administrasi2055 $administrasi2055)
    {
        $rules =
            [
                'name' => 'required',
                'notlp' => 'required',
                'jenkel' => 'required',
                'alamat' => 'required',
                'golongan2055_id' => 'required',  
            ];

        //jika data slug yang kirim tidak sama dengan data slug di table post
        if($request->nonip != $administrasi2055->nonip){
            //tambahkan validasi untuk cek apakah sudah ada atau belum// 
            $rules['nonip']= 'required|unique:penduduk2055s';
        }
        $validateData = $request->validate($rules);

       Administrasi2055::where('id',$administrasi2055->id)->update($validateData);
       return redirect('/dashboard/administrasi2055')->with('success', 'Data barang Berhasil di Update');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Administrasi2055  $administrasi2055
     * @return \Illuminate\Http\Response
     */
    public function destroy(Administrasi2055 $administrasi2055)
    {
        Administrasi2055::destroy($administrasi2055->id);
        return redirect('/dashboard/administrasi2055')->with('success','Administrasi Berhasil di Hapus');
    }
}